names={
    "inputfilename":"inputfile4.txt",
    "outputfilename":"outputfile4.txt",
}