names={
    "host" : "localhost",
    "user" : "root",
    "passwd" : "Kanisha@2523",
    "database" : "adftraining"
}