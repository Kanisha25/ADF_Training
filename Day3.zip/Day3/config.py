names={
    "inputfilename":"inputfile3.txt",
    "outputfilename":"outputfile3.txt",
}